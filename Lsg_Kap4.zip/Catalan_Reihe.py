# (c) tommyp_ger

import math

def minus(Reihe,n):
    if n > 2: Reihe = plus(Reihe,n-1) - 1/(math.sqrt(n) + 1)
    else: Reihe = - 1/(math.sqrt(n) + 1)
    return Reihe

def plus(Reihe,n):
    Reihe = minus(Reihe,n) + 1/(math.sqrt(n) - 1)
    return Reihe

# Hauptprogramm
N = int(input('Obergrenze: '))
Reihe = 0
print('Reihenwert = ',plus(0,N))