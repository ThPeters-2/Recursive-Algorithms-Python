# (c) tommyp_ger

import math

def Wurzel(n):
    if n > 1:
        return math.sqrt(n + Quadrat(n-1))
    else: return 1

def Quadrat(n):
    return (n + Wurzel(n-1))**2    

# Hauptprogramm
print('Wurzeln und Quadrate')
n = int(input('n = '))

y = Wurzel(n) if n % 2 == 1 else Quadrat(n)
print('Ergebnis: ',y)
