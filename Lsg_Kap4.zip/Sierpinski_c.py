# (c) tommyp_ger

import turtle as tu
import math

def Bucht(h,h2,Stufe):
    if Stufe == 1:
        tu.pencolor((1,0,0))
        tu.left(45); tu.forward(h2)
        tu.right(90); tu.forward(h2)
        tu.right(90); tu.forward(h2)
        tu.left(45)
        tu.pencolor((0,0,0)); tu.width(2)
    else: 
        tu.left(45)
        Passage(h,h2,Stufe-1)
        tu.pencolor((0,0,0))
        tu.left(45); tu.forward(h2)
        for i in range(3):
            Bucht(h,h2,Stufe-1); tu.forward(h2)
        tu.left(45); Passage(h,h2,Stufe-1)
        tu.left(45)

def Passage(h,h2,Stufe):
    if Stufe > 1:
        Passage(h,h2,Stufe-1)
        tu.left(45); tu.forward(2*h)
        Bucht(h,h2,Stufe-1)
        tu.forward(2*h); tu.left(45)
        Passage(h,h2,Stufe-1)
    else: 
        tu.pencolor((0,1,0))
        tu.forward(h2)
        tu.pencolor((0,0,0))

# Hauptprogramm
print('Sierpinski-Kurve')
n = int(input('n = (1,...,6) '))

# Vorbereitungen
h0 = 200
for i in range(n):
    h0 = h0*(4+math.sqrt(2))/(8+3*math.sqrt(2))
h = round(h0); h2 = round(math.sqrt(2)*h0)

tu.width(2) 
tu.speed(5)
tu.up(); tu.setpos(-100,60); tu.down()
tu.left(90)

for i in range(4):
    Bucht(h,h2,n); tu.forward(2*h)

tu.up(); tu.hideturtle()
tu.setpos(-400,-300)
tu.pencolor((0,0,0))
tu.write('fertig!',font = ("Arial",12,"normal"))
tu.exitonclick()
try:
    tu.bye()
except tu.Terminator:
    pass