# (c) tommyp_ger

import turtle as tu

def Quadrat(Laenge):
    tu.down()
    for i in range(4):
        tu.forward(Laenge)
        tu.right(90)
    tu.up()
    x = tu.xcor(); y = tu.ycor()
    tu.setpos(x+Laenge//10,y+Laenge//10)
    Dreieck(round(Laenge*0.8))

def Dreieck(Laenge):
    tu.down()
    tu.right(30)
    for i in range(3):
        tu.forward(Laenge); tu.right(120)
    tu.left(30)
    tu.up()
    x = tu.xcor(); y = tu.ycor()
    tu.setpos(x+Laenge*0.3,y+Laenge//10)
    if Laenge > minLaenge:
        Quadrat(round(Laenge*0.4))
        
# main program        
minLaenge = 40
tu.width(2) 
tu.speed(5)
tu.up(); tu.setpos(-200,-250)
tu.left(90)

Quadrat(600)

tu.up(); tu.hideturtle()
tu.setpos(-400,-300)
tu.pencolor((0,0,0))
tu.write('fertig!',font = ("Arial",12,"normal"))
tu.exitonclick()
try:
    tu.bye()
except tu.Terminator:
    pass