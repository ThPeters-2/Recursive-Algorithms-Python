# (c) tommyp_ger

def EingabeMatrix():
    n = int(input('Anzahl der Zeilen und Spalten: '))
    A = []
    print('Geben Sie die Koeffizienten zeilenweise ein!')
    for i in range(n):      
        Ai = []
        for j in range(n):
            st = 'a[' + str(i) + ',' + str(j) + '] = '
            Ai.append(float(input(st)))
        A.append(Ai)
    print('A = ',A)
    return A,n

def Dreieck(A,Rang):
    if Rang > 1:
        det = A[0][0]
        for k in range(1,Rang):
            y = A[k][0]/A[0][0]
            for j in range(Rang):               
                A[k][j] = A[k][j] - y*A[0][j]
        A1 = []
        for k in range(1,Rang):
            a = [A[k][j] for j in range(1,Rang)]
            A1.append(a)
        det *= Dreieck(A1,Rang-1)
        return det
    else: return A[0][0]
                
# main program
A,n = EingabeMatrix() 
D = Dreieck(A,n)
print('Wert der Determinante = ',D)