# (c) tommyp_ger

def EingabeMatrix():
    n = int(input('Anzahl der Zeilen und Spalten: '))
    A = []
    print('Geben Sie die Koeffizienten zeilenweise ein!')
    for i in range(n):      
        Ai = []
        for j in range(n):
            st = 'a[' + str(i) + ',' + str(j) + '] = '
            Ai.append(float(input(st)))
        A.append(Ai)
    print('A = ',A)
    return A,n

def istDreieck(A,rank):
    isdrei = True
    for i in range(1,rank): 
        if abs(A[i][0]) > epsilon: isdrei = False
    return isdrei

def findePivot(A,rank):
    value = 0; i = 0
    while (abs(A[0][0]) < epsilon) & (i < rank):
        i += 1
        if abs(A[i][0]) >= epsilon:
            A[0], A[i] = A[i], A[0]
            value += 1
    if i >= rank: value = -1
    return value, A

def Dreieck(A,Rang,expo):
    if Rang > 1:
        if (not(istDreieck(A,Rang))) & (abs(A[0][0]) < epsilon):
            value, A = findePivot(A,Rang)
            if value == -1: return 0
            else: expo += value
        det = A[0][0]
        if abs(det) < epsilon: return 0,0
        else:
            for k in range(1,Rang):
                y = A[k][0]/A[0][0]
                for j in range(Rang):               
                    A[k][j] = A[k][j] - y*A[0][j]
            A1 = []
            for k in range(1,Rang):
                a = [A[k][j] for j in range(1,Rang)]
                A1.append(a)
            d2,expo = Dreieck(A1,Rang-1,expo)
            det *= d2
            return det, expo
    else: return A[0][0],expo
                
# main program
epsilon = 1e-4; expo = 0
A,n = EingabeMatrix() 
D,expo = Dreieck(A,n,expo)
print('Wert der Determinante = ',D*(-1)**expo)