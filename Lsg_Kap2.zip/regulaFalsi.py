# (c) tommyp_ger

import math

def f(x):
    return math.sin(2*x)

def regula(l,r,Zaehler): 
    fl = f(l); fr = f(r)
    print('[',round(l,5),' , ',round(r,5),'] -> [',round(fl,6),' , ',round(fr,6),']')
    xm = (l*fr - r*fl)/(fr - fl) 
    print('xm = ',xm)
    if abs(f(xm)) < epsilon:
        print()
        print('Naeherungsloesung: ',xm)
    else:
        if fl*f(xm) <= -epsilon: regula(l,xm,Zaehler+1)
        else: regula(xm,r,Zaehler+1)

# main program 
epsilon = 1e-12
print(); print('Regula Falsi')
left = float(input('linke Grenze: '))
right = float(input('rechte Grenze: '))
regula(left,right,0)
       