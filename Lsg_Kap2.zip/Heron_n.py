# (c) tommyp_ger

def Heron(x,i):
    i += 1
    x_neu = (1-1/k)*x + a/(k*x**(k-1))
    print('Stufe ',i,' Naeherung ',x_neu)
    if abs(x_neu - x) > epsilon: Heron(x_neu,i)

# main program
print('Wurzeln mit dem Heron-Verfahren')
a = float(input('Radikand: '))
k = int(input('Wurzel Exponent: '))
d = int(input('Anzahl der Dezimalen: '))
epsilon = 10**(-d)
Heron(1,0)          