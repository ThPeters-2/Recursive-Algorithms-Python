# (c) tommyp_ger

import turtle as tu
import time

def zeichne(Laenge,Stufe):
    Laenge /= 4
    if Stufe == 0: 
        tu.forward(Laenge)
        tu.right(90)
        tu.forward(Laenge)
        tu.left(90)
        tu.forward(Laenge)
        tu.left(90)
        tu.forward(Laenge)
        tu.forward(Laenge)
        tu.right(90)
        tu.forward(Laenge) 
        tu.right(90)
        tu.forward(Laenge) 
        tu.left(90)
        tu.forward(Laenge)
    else:
        zeichne(Laenge,Stufe-1)
        tu.right(90)
        zeichne(Laenge,Stufe-1)
        tu.left(90)
        zeichne(Laenge,Stufe-1)
        tu.left(90)
        zeichne(Laenge,Stufe-1)
        zeichne(Laenge,Stufe-1)
        tu.right(90)
        zeichne(Laenge,Stufe-1)
        tu.right(90)
        zeichne(Laenge,Stufe-1)
        tu.left(90)
        zeichne(Laenge,Stufe-1)
        
# Hauptprogramm

for Zaehler in range(3):
    tu.up(); tu.setpos(-300,0); tu.down()
    tu.width(2)
    zeichne(600,Zaehler)
    time.sleep(3)
    tu.clearscreen()

#tu.up(); tu.setpos(-300,0); tu.down()
#zeichne(600,3) # sieht nett aus, braucht aber sehr lange

tu.up(); tu.hideturtle()
tu.setpos(-300,-250)
tu.pencolor((0,0,0))
tu.write('fertig!',font = ("Arial",12,"normal"))
tu.exitonclick()
try:
    tu.bye()
except tu.Terminator:
    pass