# (c) tommyp_ger

def Perm(m):
    if m == 1:
        print(A)
    for i in range(m):
        Perm(m-1)
        if m % 2 == 1:
            A[m-1], A[0] = A[0], A[m-1]
        else:
            A[m-1], A[i] = A[i], A[m-1]

# Hauptprogramm
n = int(input('n = '))
A = [i+1 for i in range(n)]
print('A = ',A); print()
Perm(n)