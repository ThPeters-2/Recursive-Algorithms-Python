# (c) tommyp_ger

Gewicht = [7,4,6,8,6]
Wert = [4,4,5,4,6]
maxGewicht = 13 # vom Rucksack

#Gewicht = [6,8,7]
#Wert = [5,6,8]
#maxGewicht = 13

#Gewicht = [12,2,1,1,4]
#Wert = [4,2,2,1,10]
#maxGewicht = 15

#Gewicht = [5, 7, 6, 8, 10, 11, 12, 15, 17, 30, 18]  
#Wert = [8, 9, 6, 5, 10, 5, 10, 17, 19, 20, 13]  
#maxGewicht = 33


def finde(x):
    posi = -1
    for j in range(n-1,x,-1):
        if (not markiert[j]): posi = j
    return posi

def saeubern(x):
    y = x + 1
    while y <= n-1: 
        markiert[y] = False
        y += 1
        
def suche(aktuell):
    global Zaehler, Basis, optiWert, optiList
    y = finde(aktuell)
    if y >= 0:
        Zaehler += 1; aktuell = y
        indList.append(aktuell)
        GewList.append(Gewicht[aktuell]); WertList.append(Wert[aktuell])
        if (sum(GewList) <= maxGewicht) & (sum(WertList) > optiWert):
            optiWert = sum(WertList); optiList = indList.copy()
        #if sum(GewList) > maxGewicht:
        #    for ii in range(aktuell+1,n): markiert[ii] = True
        print('Zaehler = ',Zaehler,' optimaler Wert = ',optiWert,' indList = ',indList)
        suche(aktuell)
    else: # backtracking
        markiert[aktuell] = True
        saeubern(indList[-1])
        indList.pop(-1); GewList.pop(-1); WertList.pop(-1)
        if indList != []: aktuell = indList[-1]
        else: 
            aktuell = -1 + Basis; Basis += 1
        if Basis < n: suche(aktuell)
        
# main program        
n = len(Gewicht)
indList, optiList, WertList, GewList = [], [], [], []
markiert = [False for i in range(n)]
Basis, Zaehler, optiWert = 0, 0, 0
suche(-1)
print()
print('optimal value: ',optiWert)
print('optimal objects: ',optiList)  
print('number of checks: ',Zaehler)