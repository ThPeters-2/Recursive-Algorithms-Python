# (c) tommyp_ger

import numpy as np

def altrek(n):
    if n == 1: return 1
    elif (n % 4) == 3: return altrek(n-2) - 1/n 
    else: return altrek(n-2) + 1/n

print(); print('Alternierende Reihe')
stn = input('n = '); n = int(stn)

print('Naeherung von pi: ',altrek(n)*4)
print('Differenz zu pi: ',altrek(n)*4 - np.pi)