# (c) tommyp_ger

import numpy as np

def altrek(n):
    if n == 1: return 1
    elif (n % 2) == 0: return altrek(n-1) - 1/n 
    else: return altrek(n-1) + 1/n

print(); print('Alternierende Harmonische Reihe')
stn = input('n = '); n = int(stn)

print('A(',n,') = ',altrek(n))
print('Differenz zu ln 2: ',np.log(2) - altrek(n))