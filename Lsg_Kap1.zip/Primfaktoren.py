# (c) tommyp_ger

def findePF(n,x):
    if n % x == 0: 
        print(x,' ',end = '')
        n = n / x
    else: x += 1
    if n >= x: findePF(n,x)

# Hauptprogramm
print('Primfaktoren')
n = int(input('n = '))
findePF(n,2)