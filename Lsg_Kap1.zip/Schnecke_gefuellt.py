# (c) tommyp_ger

import turtle as tu

def Schnecke(weit,situ,rot,gruen, blau):
    rot *= 0.85; gruen *= 1.05; blau *= 1.07
    if blau > 1: blau = 1
    if gruen > 1: gruen = 1   
    tu.pencolor((rot, gruen, blau))
    tu.fillcolor((rot, gruen, blau))
    tu.begin_fill()
    tu.up()
    tu.down()
    for i in range(2):
        tu.forward(round(weit)); tu.left(90)
        tu.forward(round(weit)); tu.left(90)
    tu.end_fill()
    if weit > 20:
        tu.right(18)
        Schnecke(weit*0.95, situ+2,rot, gruen, blau)

# Hauptprogramm
x0 = -100; y0 = 100    
rot = 1; gruen = 0.1; blau = 0.1
tu.pensize(width = 2); tu.setheading(90)
Schnecke(200,0,rot, gruen, blau)
tu.up(); tu.hideturtle()
tu.setpos(-250,-250)
tu.pencolor((0,0,0))
tu.write('fertig!',font = ("Arial",12,"normal"))
tu.exitonclick()
try:
    tu.bye()
except tu.Terminator:
    pass
