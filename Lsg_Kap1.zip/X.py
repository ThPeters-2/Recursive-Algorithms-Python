# (c) tommyp_ger

def macht_was(k):
    print(st[k],end = '')
    if st[k] != ' ': macht_was(k+1)

def macht_was2(k):
    if st[k] != ' ': macht_was2(k+1)
    print(st[k],end = '')
    
# Hauptprogramm
st = input('Gib ein Wort ein und dann <enter> ') 
st += ' '
macht_was(0)  
print()
macht_was2(0)
print()
 