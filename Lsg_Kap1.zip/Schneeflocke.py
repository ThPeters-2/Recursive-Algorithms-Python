# (c) tommyp_ger

import turtle as tu
import random as rd

def Flocke(x):
    rot = rd.uniform(0,1)
    gruen = rd.uniform(0,1)
    blau = rd.uniform(0,1)
    tu.pencolor(rot, gruen, blau)
    if n in [3,4]: k = 0.5
    else: k = 0.4
    for i in range(n):
        tu.forward(x)
        if x > 20: Flocke(k*x)
        tu.back(x)
        tu.right(Winkel)
      
# Hauptprogramm
print(); print('Schneeflocken') 
n = int(input('Anzahl Strahlen (3..6): '))   
Winkel = 360/n
x = 600/n
tu.width(2)    
Flocke(x)
tu.up(); tu.hideturtle()
tu.setpos(-300,-150)
tu.pencolor((0,0,0))

tu.write('fertig!',font = ("Arial",12,"normal"))
tu.exitonclick()
try:
    tu.bye()
except tu.Terminator:
    pass