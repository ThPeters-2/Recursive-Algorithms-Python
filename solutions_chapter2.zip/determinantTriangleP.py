# (c) drthpeters

def enterMatrix():
    n = int(input('number of rows/columns: '))
    A = []
    print('enter coefficients line by line')
    for i in range(n):      
        Ai = []
        for j in range(n):
            st = 'a[' + str(i) + ',' + str(j) + '] = '
            Ai.append(float(input(st)))
        A.append(Ai)
    print('A = ',A)
    return A,n

def isTriangle(A,rank):
    istri = True
    for i in range(1,rank): 
        if abs(A[i][0]) > epsilon: istri = False
    return istri

def findPivot(A,rank):
    value = 0; i = 0
    while (abs(A[0][0]) < epsilon) & (i < rank):
        i += 1
        if abs(A[i][0]) >= epsilon:
            A[0], A[i] = A[i], A[0]
            value += 1
    if i >= rank: value = -1
    return value, A

def triangle(A,rank,expo):
    if rank > 1:
        if (not(isTriangle(A,rank))) & (abs(A[0][0]) < epsilon):
            value, A = findPivot(A,rank)
            if value == -1: return 0
            else: expo += value
        det = A[0][0]
        if abs(det) < epsilon: return 0,0
        else:
            for k in range(1,rank):
                y = A[k][0]/A[0][0]
                for j in range(rank):               
                    A[k][j] = A[k][j] - y*A[0][j]
            A1 = []
            for k in range(1,rank):
                a = [A[k][j] for j in range(1,rank)]
                A1.append(a)
            d2,expo = triangle(A1,rank-1,expo)
            det *= d2
            return det, expo
    else: return A[0][0],expo
                
# main program
epsilon = 1e-4; expo = 0
A,n = enterMatrix() 
D,expo = triangle(A,n,expo)
print('value of the determinant = ',D*(-1)**expo)