# (c) tommyp_ger

import turtle as tu
import random as rd

def bestimmeFarbe():
    rot = rd.uniform(0,0.9)
    gruen = rd.uniform(0,0.9)
    blau = rd.uniform(0,0.9)
    return (rot, gruen, blau)
    
def Drache(Laenge,Stufe):
    
    if Stufe == 0: tu.forward(Laenge)
    else:
        Laenge = round(Laenge*0.707)
        tu.left(45)
        Drache(Laenge,Stufe-1)
        tu.right(90)
        Drache(Laenge,Stufe-1)
        tu.left(45)

# Hauptprogramm

tu.width(3) 

for Stufe in range(6):
    tu.pencolor(bestimmeFarbe())
    tu.up()
    tu.setpos(-160,-50)
    tu.down()
    Drache(270,Stufe)

tu.up(); tu.hideturtle()
tu.setpos(-300,-150)
tu.pencolor((0,0,0))
tu.write('fertig!',font = ('Arial',12,'normal'))
tu.exitonclick()
try: tu.bye()
except tu.Terminator: pass