# (c) tommyp_ger

import numpy as np
import scipy.optimize as scop

def lies(Dateiname):
    Daten = np.loadtxt(Dateiname)
    print('Daten = '); print(Daten)
    obj = Daten[0][:-1]
    print(); print('obj = ',obj)
    A = [Daten[i][:-1] for i in range(1,len(Daten))]
    B = [Daten[i][-1] for i in range(1,len(Daten))]
    print('A = ',A); print('B = ',B)
    return obj, A, B

def loese_LP(obj, A, B):
    Erfolg = True
    opt = scop.linprog(c=obj, A_ub=A, b_ub=B, method="highs")
    x = opt.x; y = opt.fun
    if opt.status > 0: Erfolg = False
    return x,y,Erfolg

def ist_ganz(x):
    xniedrig = np.floor(x); xhoch = np.ceil(x)
    b = False
    if (abs(x-xniedrig) < epsilon) or (abs(xhoch - x) < epsilon): b = True
    return b

def alle_ganz(x):
    b = True
    for i in range(len(x)):
        if ist_ganz(x[i]) == False: b = False
    return b

def links(ind,x,A,B):
    A_ = [0 for i in range(len(x))]
    A_[ind] = 1
    A0 = A + [A_]; B0 = B + [np.floor(x[ind])]
    print('A0 = ',A0)
    print('B0 = ',B0)
    x0,y0,Erfolg = loese_LP(obj,A0,B0)
    print('Variablen linker Zweig: ',x0)
    print('Wert der Zielfunktion: ',y0)
    print('Erfolg: ',Erfolg); print()
    if Erfolg == False: y0 = np.inf
    return x0,y0,A0,B0,Erfolg
    
def rechts(ind,x,A,B):
    A_ = [0 for i in range(len(x))]
    A_[ind] = -1
    A1 = A + [A_]; B1 = B + [-np.ceil(x[ind])]
    print('A1 = ',A1)
    print('B1 = ',B1)
    x1,y1,Erfolg = loese_LP(obj,A1,B1)
    print('Variablen rechter Zweig: ',x1)
    print('Wert der Zielfunktion: ',y1)
    print('Erfolg: ',Erfolg); print()
    if Erfolg == False: y1 = np.inf
    return x1,y1,A1,B1,Erfolg


def branch(ind,x,A,B,xList,yList):
    
    xl,yl,Al,Bl,Erfolg = links(ind,x,A,B) 
    if Erfolg:
        if alle_ganz(xl):
            print('Loesung gefunden x = ',xl,' y = ',yl); print()
            xList.append(xl); yList.append(yl)
        elif yl != np.inf: 
            i = 0
            while (i < len(xl)) & ist_ganz(xl[i]) : i += 1
            branch(i,xl,Al,Bl,xList,yList)
        
    xr,yr,Ar,Br,Erfolg = rechts(ind,x,A,B)
    if Erfolg:
        if alle_ganz(xr):
            print('Loesung gefunden x = ',xr,' y = ',yr); print()
            xList.append(xr); yList.append(yr)
        elif yr != np.inf: 
            i = 0
            while (i < len(xr)) & ist_ganz(xr[i]) : i += 1
            branch(i,xr,Ar,Br,xList,yList)
            
# Hauptprogramm ----------------------------------------------------------------
epsilon = 1e-6

xList, yList = [], []
obj, A, B = lies('ILP1.txt')

x,y, Erfolg = loese_LP(obj,A,B)
print(); print('LP Vereinfachung : ',x)
print('Wert der Zielfunktion: ',y)

if Erfolg:
    if alle_ganz(x): print('Dies ist die optimale ganzzahlige Loesung!')
    else:
        i = 0
        while (i < len(x)) & ist_ganz(x[i]): i += 1
        gefunden = branch(i,x,A,B,xList,yList)
        if gefunden:
            print('yList = ',yList)
            print('xList = ',xList)
        else:
            print('keine Loesung des ILP!')
        
        if yList != []:
            ymin = min(yList)
            xmin = xList[np.argmin(yList)]; 
            print(); print('optimale ganzzahlige Loesung: ')
            print('optimaler Zielwert: ',ymin)
            ixmin = [int(xmin[i]) for i in range(len(xmin))]
            print('Werte der Variablen: ',ixmin)
else: print('Das System ist unzulaessig!')
