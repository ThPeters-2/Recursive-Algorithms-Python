# (c) tommyp_ger

def schiebe(x,y,z,k,Zaehler):
    if k == 1: 
        Zaehler += 1
        print('Scheibe ',k,' ',x,' -> ',y)       
    else: 
        Zaehler = schiebe(x,z,y,k-1,Zaehler)
        Zaehler += 1
        print('Scheibe ',k,' ',x,' -> ',y)
        Zaehler = schiebe(z,y,x,k-1,Zaehler)
    return Zaehler

#------------------------------------------------------------------------------
# Hauptprogramm  
print(); print('Tuerme von Hanoi')
n = int(input('Anzahl der Scheiben (<= 6): '))

Zaehler = schiebe('Quellturm','Zielturm','Hilfsturm',n,0)
print(); print('Aufrufe von "schiebe": ',Zaehler)        