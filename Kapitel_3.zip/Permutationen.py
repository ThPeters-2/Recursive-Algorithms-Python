# (c) tommyp_ger

def swap(p,i,j):
    p[j], p[i] = p[i], p[j]
    return p

def perm(n):
    if n == 2: 
        print(p)        
        swap(p,pmax-2,pmax-1)
        print(p)       
        swap(p,pmax-2,pmax-1)
    else:
        perm(n-1)       
        for i in range(pmax-n+1,pmax):
            swap(p,pmax-n,i)
            perm(n-1)
        for i in range(pmax-n+1,pmax): swap(p,i-1,i)
        
#- Hauptprogramm --------------------------------------------------------------

print('Permutationen')
pmax = int(input('Geben Sie die Ordnung ein! (2..6) '))
p = [i+1 for i in range(pmax)]
perm(pmax)
    