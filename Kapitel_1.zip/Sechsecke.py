
# (c) tommyp_ger

import turtle as tu

def Sechseck(a, rot, blau):
    rot *= 0.8; blau *= 1.25
    if blau > 1: blau = 1
    tu.pencolor(rot,0,blau)
    tu.up()
    tu.setpos(-0.5*a,-0.866*a)
    tu.down()
    for i in range(6):
        tu.forward(a); tu.left(60)
    tu.up()
    tu.setpos(0,0)
    if a > 25:
        Sechseck(a*0.8, rot, blau)

# Hauptprogramm
rot = 1; blau = 0.2
tu.pensize(width = 3)
Sechseck(200, rot, blau)
tu.up(); tu.hideturtle()
tu.setpos(-300,-250)
tu.pencolor((0,0,0))
tu.write('fertig!',font = ("Arial",12,"normal"))
tu.exitonclick()
try: tu.bye()
except tu.Terminator: pass
