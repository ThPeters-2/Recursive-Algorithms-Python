# (c) tommyp_ger

def istPalindrom(st):
    if len(st) <= 1: p = True
    else:
        if st[0] != st[-1]: p = False
        else: p = istPalindrom(st[1:-1])
    return p

def checkPalindrom(st):
    stu = st.upper()
    stu = stu.replace(' ','')
    stu = stu.replace(',','')
    print(st)
    palin = istPalindrom(stu)
    if palin == True: print('ist ein Palindrom.')
    else: print('ist kein Palindrom.')
    print()

checkPalindrom('Uhu')
checkPalindrom('Otto')
checkPalindrom('Rentner')
checkPalindrom('12022021')
checkPalindrom('Regenpfeifer')
checkPalindrom('Reliefpfeiler')
checkPalindrom('Dreh mal am Herd')
checkPalindrom('Die Liebe ist Sieger, stets rege ist sie bei Leid')
checkPalindrom('65536')
checkPalindrom('Ein Esel lese nie')
