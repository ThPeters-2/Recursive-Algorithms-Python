# (c) tommyp_ger

gamma = 0.577215664901533
import math

def harmrek(n):
    if n == 1: return 1
    else: return harmrek(n-1) + 1/n

# main program
print(); print('Harmonische Reihe')
n = int(input('n = '))

print('H(',n,') = ',harmrek(n))

print()
print('approximiert: ',math.log(n)+gamma)
