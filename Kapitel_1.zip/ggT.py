
# (c) tommyp_ger

def ggT(x,y):
    if x < 0: x = -x
    if y < 0: y = -y
    r = 1
    while r > 0:
        r = x % y; x = y; y = r
    print('Der ggT ist ',x)
    z = int(input('neue Zahl: '))
    if z != 0: ggT(x,z) 

# Hauptprogramm
print(); print('Größter gemeinsamer Teiler')
print('bitte Zahlen eingeben, am Ende eine 0')
a, b = 0, 0
while a == 0: a = int(input('erste Zahl: '))
while b == 0: b = int(input('zweite Zahl: '))
ggT(a,b)