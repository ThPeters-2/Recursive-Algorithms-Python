
# (c) tommyp_ger

import turtle as tu
import random as rd

def Form(Zaehler,x):
    rot = rd.uniform(0,1)
    gruen = rd.uniform(0,1)
    blau = rd.uniform(0,1)
    tu.pencolor((rot,gruen,blau))
    for i in range(n):
        tu.forward(x)
        tu.right(Winkel)
    tu.right(7)
    if Zaehler < 360/7: Form(Zaehler+1,x)
    
# main program
print(); print('Rosetten') 
n = int(input('Anzahl der Ecken (3..6): '))   
Winkel = 360/n
tu.width(2)    
Form(0,600/n)
tu.up(); tu.hideturtle()
tu.setpos(-300,-150)
tu.pencolor((0,0,0))

tu.write('fertig!',font = ("Arial",12,"normal"))
tu.exitonclick()
try: tu.bye()
except tu.Terminator: pass