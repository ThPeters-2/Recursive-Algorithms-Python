
# (c) tommyp_ger

NamenListe = []
with open('names_sort.txt') as f:
    lines = f.readlines()

for i in range(len(lines)):
    NamenListe.append(lines[i][:-1]) 

#------------------------------------------------------------------------------
def Suche(l,r):
    gefunden = False
    m = round((l+r)/2)
    print(' Name[',m,'] = ',NamenListe[m])
    if na == NamenListe[m]: gefunden = True
    if (na < NamenListe[m]) & (l < m): gefunden,m = Suche(l,m-1)
    if (na > NamenListe[m]) & (m < r): gefunden,m = Suche(m+1,r)
    return gefunden, m

# main program ----------------------------------------------------------------
n = len(NamenListe)
print()  
print('Binaere Suche von Namen ',n,' Vornamen'); print()
na = input('Name: '); print()
found, m = Suche(0,n-1)
print()
if found: print(na + ' ist Nummer '+ str(m),'.')
else: print(na + ' ist nicht in der Liste der Vornamen.')