# (c) tommyp_ger

def gerade(n):
    print(n,end = ' ')
    n = n //2
    if n % 2 == 0: gerade(n)
    else: ungerade(n)

def ungerade(n):
    if n == 1: print(1)
    else: 
        print(n,end = ' ')
        gerade(3*n+1)

print('Collatz-Problem')
n = int(input('ungerade Zahl n = '))
ungerade(n)
        