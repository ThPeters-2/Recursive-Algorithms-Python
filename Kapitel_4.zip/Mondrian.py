# (c) tommyp_ger

import turtle as tu
import random as rd

def fuellen(links,rechts,unten,oben,c):
    tu.setpos(links,unten)
    tu.down()
    if c == 0: tu.fillcolor((0,0,0)) 
    elif c == 1: tu.fillcolor((1,0,0))
    elif c == 2: tu.fillcolor((0,0,1))
    else: tu.fillcolor((1,1,0))
    tu.begin_fill()
    tu.setpos(links,unten)
    for i in range(2):
        tu.forward(oben-unten); tu.right(90)
        tu.forward(rechts-links); tu.right(90)
    tu.end_fill()
    tu.up()

def faerben(links,rechts,unten,oben): 
    z = rd.randint(1,18)
    if z in Farben:
        fuellen(links,rechts,unten,oben,z)

def horizontal(links,rechts,unten,oben):
    Spanne = oben - unten
    if Spanne >= minSpanne:
        tief = Spanne//4 + unten
        hoch = -Spanne//4 + oben
        if unten < 0: Mitte = unten
        else: Mitte = -1
        while (Mitte < tief) or (Mitte > hoch):
            Mitte = unten + rd.randint(1,Spanne)
        fuellen(links,rechts,Mitte-halb,Mitte+halb,0)
        vertikal(links,rechts,unten,Mitte-halb)
        vertikal(links,rechts,Mitte+halb,oben)
    else: faerben(links,rechts,unten,oben)
    
def vertikal(links,rechts,unten,oben):
    Spanne = rechts - links
    if Spanne >= minSpanne:
        li = Spanne//4 + links
        re = -Spanne//4 + rechts
        if links < 0: Mitte = links
        else: Mitte = -1
        while (Mitte < li) or (Mitte > re):
            Mitte = links + rd.randint(1,Spanne)
        fuellen(Mitte-halb,Mitte+halb,unten,oben,0)
        horizontal(links,Mitte-halb,unten,oben)
        horizontal(Mitte+halb,rechts,unten,oben)
    else: faerben(links,rechts,unten,oben)

# Hauptprogramm 

minSpanne = 120; halb = 5
Farben = {1,2,3}

tu.speed(8)
tu.up(); tu.hideturtle(); tu.left(90)
vertikal(-300,300,-200,200)
tu.up()
tu.setpos(-300,-250)
tu.pencolor((0,0,0))
tu.write('fertig!',font = ("Arial",12,"normal"))
tu.exitonclick()
try: tu.bye()
except tu.Terminator: pass