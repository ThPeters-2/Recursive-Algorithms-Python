# (c) drthpeters

import numpy as np

def altrek(n):
    if n == 1: return 1
    elif (n % 4) == 3: return altrek(n-2) - 1/n 
    else: return altrek(n-2) + 1/n

print(); print('Alternating Series')
stn = input('n = '); n = int(stn)

print('Approximation of pi: ',altrek(n)*4)
print('Differencd from pi: ',altrek(n)*4 - np.pi)