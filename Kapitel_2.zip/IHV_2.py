# (c) tommyp_ger

def Koeff():
    global n, a
    print('p(x) = a_0*x^0 + ... + a_n*x^n')
    n = int(input('Grad des Polynoms: (<= 6) '))
    if n > 6: Koeff()
    a = []
    for i in range(n+1):
        b = float(input('enter coefficient: '))
        a.append(b)

def Polynom():
    print('Sie haben eingegeben:')
    st = ''
    for i in range(n+1):
        st = st + str(a[i]) + '*x^' + str(i)
        if i < n: st += ' + '
    print(st)
        
def Grenzen(n,a):
    global M
    M = 0
    for j in range(n+1):
        M += abs(a[j]/a[n])

def f(x):
    y = a[n]
    for j in range(n,0,-1): y = y*x + a[j-1]
    return y

def IHV(l,r): # Intervallhalbierungsverfahren
    fl = f(l); fr = f(r)
    print('[',round(l,5),' , ',round(r,5),'] -> [',round(fl,6),' , ',round(fr,6),']')
    if r - l < epsilon:
        print(); print('Eine Nullstelle liegt im Intervall')
        print('[',l,',',r,'].'); print()
    else:
        if fl*f((l+r)/2) <= 0: IHV(l,(l+r)/2)
        else: IHV((l+r)/2,r)

def WT(n,a): # Wertetabelle
    Schritt = 0.1
    print('Wertetabelle'); print()
    for i in range(round(-M/Schritt),round(M/Schritt)):
        print('  ',i*Schritt,'  ->   ',round(f(i*Schritt),3))
        if f(i*Schritt)*f((i+1)*Schritt) < -epsilon:
            print(); print('Intervallhalbierung')
            IHV(i*Schritt,(i+1)*Schritt)
        if abs(f(i*Schritt)) < epsilon:
            print(); print('Eine Nullstelle liegt bei ',i*Schritt)

# main program 
max = 6
epsilon = 1e-5
print(); print('Intervallhalbierungsverfahren')
ok = False
while not(ok):
    Koeff() 
    Polynom()
    print(); Ant = input('alles richtig? (j/n) ')
    if Ant in ['J','j']: ok = True
Grenzen(n,a)
WT(n,a)
       