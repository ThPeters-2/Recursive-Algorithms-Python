
# (c) tommyp_ger

def prob(Stufe,weiss):
    if (weiss > Stufe) or (weiss < 0): return 0
    else:
        if Stufe == 1: 
            if weiss == 1: return p
            else: return 1 - p
        else:
            return prob(1,0)*prob(Stufe-1,weiss)+prob(1,1)*prob(Stufe-1,weiss-1)

# main program
print(); print('Binomialverteilung')
w = int(input('Anzahl weisser Kugeln: '))
s = int(input('Anzahl schwarzer Kugeln: '))    
p = w/(w + s)
n = int(input('Anzahl der Ziehungen: '))  
for k in range(n+1):
    print('Wahrscheinlichkeit fuer ',k,' weisse Kugeln: ',prob(n,k))      