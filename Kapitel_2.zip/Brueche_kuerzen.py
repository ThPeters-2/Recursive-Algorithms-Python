# (c) tommyp_ger

def suche_prim(prim, Zaehler, Nenner):
    moeglich = True; Erfolg = False
    if (Zaehler % prim != 0) or (Nenner % prim != 0):
        prim += 1
        if (Zaehler < prim) or (Nenner < prim): moeglich = False
        if moeglich: 
            prim, Erfolg = suche_prim(prim, Zaehler, Nenner)
    else: Erfolg = True
    return prim, Erfolg

def kuerze(prim, Zaehler, Nenner):
    prim, Erfolg = suche_prim(prim, Zaehler, Nenner)
    if Erfolg:
        Zaehler = Zaehler // prim
        Nenner = Nenner // prim
        print(' = ',Zaehler,'/',Nenner,end = ' ')
        kuerze(prim, Zaehler, Nenner)

# main program
print(); print('Brueche kuerzen')
moeglich = True; prim = 2
Zaehler = int(input('Zaehler: '))
Nenner = int(input('Nenner: '))
print()
print(Zaehler,'/',Nenner,end = ' ')
kuerze(prim, Zaehler, Nenner)       
