# (c) tommyp_ger

import turtle as tu

def schreibe_Koeff(X,x,y):
    offset = 0
    if X < 0:
        tu.setpos(x-7,y)
        tu.write('(',font = ("Courier",12,"bold"))
        tu.setpos(x,y)
        tu.write(X,font = ("Courier",12,"bold"))
        lz = len(str(X))
        tu.setpos(x+lz*12-5,y)
        tu.write(')',font = ("Courier",12,"bold"))
        offset = lz*12
    else: 
        tu.setpos(x,y)
        tu.write(X,font = ("Courier",12,"bold"))
        lz = len(str(X))
        offset = lz*12
    return offset

def schreibe_Matrix(A,n,x,y):
    Stufe = 12
    tu.up()
    tu.hideturtle()
    delta = 0
    for j in range(n):
        Sp = []; Y = []
        for i in range(n): 
            Sp.append(len(str(A[i][j]))); Y.append(str(A[i][j]))
        mSp = max(Sp)
        for i in range(n):
            while len(Y[i]) < mSp: Y[i] = ' ' + Y[i]
            tu.setpos(x+delta,y-i*20)
            tu.write(Y[i],font = ("Courier",12,"bold")) 
        delta += Stufe*(mSp+1)
    delta -= Stufe
    tu.setpos(x-7,y+20); tu.down(); tu.right(90)
    tu.forward(n*20); tu.up()
    tu.setpos(x+delta+3,y+20); tu.down()
    tu.forward(n*20); tu.up()
    tu.left(90) 
    return delta+3

def EingabeMatrix():
    print('Anzahl Zeilen/Spalten = 3')
    A = []
    print('Koeffizienten zeilenweise eingeben')
    for i in range(3):      
        Ai = []
        for j in range(3):
            st = 'a[' + str(i) + ',' + str(j) + '] = '
            Ai.append(int(input(st)))
        A.append(Ai)
    print('A = ',A)
    return A

def det(A,Rang,Spalte,ind):
    if Rang == 2:
        # find correct indices
        k = list(ind)
        if k[0] > k[1]: x = k[0]; k.pop(0); k.append(x)
        Erg = A[k[0]][Spalte]*A[k[1]][Spalte+1] - A[k[1]][Spalte]*A[k[0]][Spalte+1]
    else:
        Erg = 0; Zaehler = 0; i = 0; C = []
        xpos = -200; Stufe = 12
        for i in range(n):
            if i in ind:
                # entferne Zeile i
                ind = ind - {i}
                X = A[i][Spalte]
                if Zaehler % 2 == 1: X = -X
                xpos += schreibe_Koeff(X,xpos,240 - (2*n)*20) + Stufe
                tu.setpos(xpos,240 - (2*n)*20)
                tu.write('*',font = ("Courier",12,"bold"))
                xpos += 2*Stufe
                B = []
                for ii in range(Rang):
                    if ii != i:
                        Bii = []
                        for jj in range(1,n): Bii.append(A[ii][jj])
                        B.append(Bii)
                xpos += schreibe_Matrix(B,Rang-1,xpos,240 - (2*n-1)*20-10) + Stufe
                tu.setpos(xpos,240 - (2*n)*20)
                if i < n-1: tu.write('+',font = ("Courier",12,"bold"))
                else: tu.write('=',font = ("Courier",12,"bold"))
                xpos += 2*Stufe
                
                c = det(A,Rang-1,Spalte+1,ind)
                Erg += (-1)**Zaehler*A[i][Spalte]*c; C.append(c)
                
                Zaehler += 1
                ind = ind.union({i})
        
        xpos = -200
        for k in range(n):
            X = A[k][Spalte]
            if k % 2 == 1: X = -X
            xpos += schreibe_Koeff(X,xpos,240 - (3.5*n)*20) + Stufe
            tu.setpos(xpos,240 - (3.5*n)*20)
            tu.write('*',font = ("Courier",12,"bold"))
            xpos += 2*Stufe
            xpos += schreibe_Koeff(C[k],xpos,240 - (3.5*n)*20) + 2*Stufe
            tu.setpos(xpos,240 - (3.5*n)*20)
            if k < n-1: tu.write('+',font = ("Courier",12,"bold"))
            else: tu.write('=',font = ("Courier",12,"bold"))
            xpos += 2*Stufe
    return Erg

# Hauptprogramm
A = EingabeMatrix()
n = 3
Indizes = {j for j in range(n)}

tu.up()
tu.setpos(-200,300)
tu.write('Determinante, nach der ersten Spalte entwickelt',font = ("Courier",12,"bold"))

delta = schreibe_Matrix(A,n,-50,240) # matrix given
tu.setpos(-50 + delta + 7,240 - 10*(n-1))
tu.write('=',font = ("Courier",12,"bold"))

D = det(A,n,0,Indizes)
print('Wert der Determinante: ',D)
tu.setpos(-50,240 - (5*n)*20 + 20)        
tu.write(D,font = ("Courier",12,"bold")) 
tu.exitonclick()
try: tu.bye()
except tu.Terminator: pass
             