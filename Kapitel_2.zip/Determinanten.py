# (c) tommyp_ger

def EingabeMatrix():
    n = int(input('Anzahl der Zeilen/Spalten: '))
    A = []
    print('Koeffizienten zeilenweise eingeben')
    for i in range(n):      
        Ai = []
        for j in range(n):
            st = 'a[' + str(i) + ',' + str(j) + '] = '
            Ai.append(float(input(st)))
        A.append(Ai)
    print('A = ',A)
    return A,n

def det(A,Rang,Spalte,ind):
    if Rang == 2:
        # finde richtige Indizes
        k = list(ind)
        if k[0] > k[1]: x = k[0]; k.pop(0); k.append(x)
        # zweireihige Determinante
        res = A[k[0]][Spalte]*A[k[1]][Spalte+1] - A[k[1]][Spalte]*A[k[0]][Spalte+1]
    else:
        res = 0; Zaehler = 0; i = 0
        for i in range(n):
            if i in ind:
                # Zeile i entfernen!
                ind = ind - {i}
                res += (-1)**Zaehler*A[i][Spalte]*det(A,Rang-1,Spalte+1,ind)
                Zaehler += 1
                ind = ind.union({i})
    return res

# Hauptprogramm
A,n = EingabeMatrix()
Indizes = {j for j in range(n)}
print('Wert der Determinante: ',det(A,n,0,Indizes))   