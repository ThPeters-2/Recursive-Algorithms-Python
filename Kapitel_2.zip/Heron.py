# (c) tommyp_ger

def Heron(x,i):
    i += 1
    x_neu = 0.5*(x + a/x)
    print('Schritt ',i,'[',a/x_neu,',',x_neu,']')
    if x_neu - a/x_neu > epsilon: Heron(x_neu,i)

# Hauptprogramm
print('Heron-Verfahren zur Berechnung von Quadratwurzeln')
a = float(input('Radikand = '))
d = int(input('Anzahl von Dezimalen: '))
epsilon = 10**(-d)
Heron(1,0)          