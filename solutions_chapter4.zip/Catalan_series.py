# (c) tommyp_ger

import math

def minus(series,n):
    if n > 2: series = plus(series,n-1) - 1/(math.sqrt(n) + 1)
    else: series = - 1/(math.sqrt(n) + 1)
    return series

def plus(series,n):
    series = minus(series,n) + 1/(math.sqrt(n) - 1)
    return series

# main program
N = int(input('limit: '))
series = 0
print('value = ',plus(0,N))