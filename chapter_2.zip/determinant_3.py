# -*- coding: utf-8 -*-
"""
Created on Tue Jul 27 10:05:02 2021

@author: Tommy
"""

import turtle as tu

def write_coeff(X,x,y):
    offset = 0
    if X < 0:
        tu.setpos(x-7,y)
        tu.write('(',font = ("Courier",12,"bold"))
        tu.setpos(x,y)
        tu.write(X,font = ("Courier",12,"bold"))
        lz = len(str(X))
        tu.setpos(x+lz*12-5,y)
        tu.write(')',font = ("Courier",12,"bold"))
        offset = lz*12
    else: 
        tu.setpos(x,y)
        tu.write(X,font = ("Courier",12,"bold"))
        lz = len(str(X))
        offset = lz*12
    return offset

def write_matrix(A,n,x,y):
    step = 12
    tu.up()
    tu.hideturtle()
    delta = 0
    for j in range(n):
        col = []; Y = []
        for i in range(n): 
            col.append(len(str(A[i][j]))); Y.append(str(A[i][j]))
        mcol = max(col)
        for i in range(n):
            while len(Y[i]) < mcol: Y[i] = ' ' + Y[i]
            tu.setpos(x+delta,y-i*20)
            tu.write(Y[i],font = ("Courier",12,"bold")) 
        delta += step*(mcol+1)
    delta -= step
    tu.setpos(x-7,y+20); tu.down(); tu.right(90)
    tu.forward(n*20); tu.up()
    tu.setpos(x+delta+3,y+20); tu.down()
    tu.forward(n*20); tu.up()
    tu.left(90) 
    return delta+3

def enterMatrix():
    print('number of rows/columns = 3')
    A = []
    print('enter integer coefficients line by line')
    for i in range(3):      
        Ai = []
        for j in range(3):
            st = 'a[' + str(i) + ',' + str(j) + '] = '
            Ai.append(int(input(st)))
        A.append(Ai)
    print('A = ',A)
    return A

def det(A,rank,column,ind):
    if rank == 2:
        # find correct indices
        k = list(ind)
        if k[0] > k[1]: x = k[0]; k.pop(0); k.append(x)
        res = A[k[0]][column]*A[k[1]][column+1] - A[k[1]][column]*A[k[0]][column+1]
    else:
        res = 0; count = 0; i = 0; C = []
        xpos = -200; step = 12
        for i in range(n):
            if i in ind:
                # remove row i
                ind = ind - {i}
                X = A[i][column]
                if count % 2 == 1: X = -X
                xpos += write_coeff(X,xpos,240 - (2*n)*20) + step
                tu.setpos(xpos,240 - (2*n)*20)
                tu.write('*',font = ("Courier",12,"bold"))
                xpos += 2*step
                B = []
                for ii in range(rank):
                    if ii != i:
                        Bii = []
                        for jj in range(1,n): Bii.append(A[ii][jj])
                        B.append(Bii)
                    #print('B = ',B)
                xpos += write_matrix(B,rank-1,xpos,240 - (2*n-1)*20-10) + step
                tu.setpos(xpos,240 - (2*n)*20)
                if i < n-1: tu.write('+',font = ("Courier",12,"bold"))
                else: tu.write('=',font = ("Courier",12,"bold"))
                xpos += 2*step
                
                c = det(A,rank-1,column+1,ind)
                res += (-1)**count*A[i][column]*c; C.append(c)
                
                count += 1
                ind = ind.union({i})
        
        xpos = -200
        for k in range(n):
            X = A[k][column]
            if k % 2 == 1: X = -X
            xpos += write_coeff(X,xpos,240 - (3.5*n)*20) + step
            tu.setpos(xpos,240 - (3.5*n)*20)
            tu.write('*',font = ("Courier",12,"bold"))
            xpos += 2*step
            xpos += write_coeff(C[k],xpos,240 - (3.5*n)*20) + 2*step
            tu.setpos(xpos,240 - (3.5*n)*20)
            if k < n-1: tu.write('+',font = ("Courier",12,"bold"))
            else: tu.write('=',font = ("Courier",12,"bold"))
            xpos += 2*step
    return res

# main program
A = enterMatrix()
n = 3
indices = {j for j in range(n)}

tu.up()
tu.setpos(-200,300)
tu.write('Determinant developed by first column',font = ("Courier",12,"bold"))

delta = write_matrix(A,n,-50,240) # matrix given
tu.setpos(-50 + delta + 7,240 - 10*(n-1))
tu.write('=',font = ("Courier",12,"bold"))

D = det(A,n,0,indices)
print('value of the determinant: ',D) 
tu.setpos(-50,240 - (5*n)*20 + 20)        
tu.write(D,font = ("Courier",12,"bold")) 
tu.exitonclick()
try: tu.bye()
except tu.Terminator: pass
             